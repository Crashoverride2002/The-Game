<?php
/**
 * @package    Com.Api
 *
 * @copyright  Copyright (C) 2005 - 2017 Techjoomla, Techjoomla Pvt. Ltd. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die();

// @FixMe Get the purpose of this file
// This file is just here to trick Joomla's Article model to act as if we are loading an article
require_once JPATH_ADMINISTRATOR . '/components/com_content/helpers/content.php';
