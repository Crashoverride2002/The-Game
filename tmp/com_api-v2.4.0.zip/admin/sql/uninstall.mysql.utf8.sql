DROP TABLE IF EXISTS `#__api_keys`;
DROP TABLE IF EXISTS `#__api_logs`;
